
public class State {
	public int player = 1; //0 for the computer, 1 for the human
}
